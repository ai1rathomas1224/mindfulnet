import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(TicTacToe());

class TicTacToe extends StatefulWidget {
  @override
  _TicTacToeState createState() => _TicTacToeState();
}

class _TicTacToeState extends State<TicTacToe> {
  List<String> board = ['', '', '', '', '', '', '', '', ''];
  String _currentPlayer = 'X';

  void _playMove(int index) {
    setState(() {
      if (board[index] == '') {
        board[index] = _currentPlayer;
        _checkForWinner();
        _togglePlayer();
      }
    });
  }

  void _checkForWinner() {
    // Check rows
    for (int i = 0; i < 9; i += 3) {
      if (board[i] == _currentPlayer &&
          board[i + 1] == _currentPlayer &&
          board[i + 2] == _currentPlayer) {
        _showWinnerDialog();
      }
    }

    // Check columns
    for (int i = 0; i < 3; i++) {
      if (board[i] == _currentPlayer &&
          board[i + 3] == _currentPlayer &&
          board[i + 6] == _currentPlayer) {
        _showWinnerDialog();
      }
    }

    // Check diagonals
    if (board[0] == _currentPlayer &&
        board[4] == _currentPlayer &&
        board[8] == _currentPlayer) {
      _showWinnerDialog();
    }
    if (board[2] == _currentPlayer &&
        board[4] == _currentPlayer &&
        board[6] == _currentPlayer) {
      _showWinnerDialog();
    }
  }

  void _showWinnerDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Winner'),
          content: Text('$_currentPlayer wins!'),
          actions: [
            TextButton(
              child: Text('Restart'),
              onPressed: () {
                Navigator.of(context).pop();
                _resetGame();
              },
            ),
          ],
        );
      },
    );
  }

  void _resetGame() {
    setState(() {
      board = ['', '', '', '', '', '', '', '', ''];
      _currentPlayer = 'X';
    });
  }

  void _togglePlayer() {
    if (_currentPlayer == 'X') {
      _currentPlayer = 'O';
    } else {
      _currentPlayer = 'X';
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tic Tac Toe',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Tic Tac Toe'),
        ),
        body: Center(
          child: GridView.builder(
            itemCount: 9,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
            ),
            itemBuilder: (BuildContext context, int index) {
              return TextButton(
                child: Text(board[index]),
                onPressed: () {
                  _playMove(index);
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
