import 'package:flutter/material.dart';

import 'package:untitled11/Gamecenter.dart';
import 'package:untitled11/Timer.dart';
import 'package:untitled11/logbook.dart';

void main() => runApp(MaterialApp(home: Home()));

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[100],
      appBar: AppBar(
        title: Text(
          'Mindful Net',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            fontFamily: 'Pacifico',
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.pink,
        leading: GestureDetector(
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Logbook()));
          },
          child: Icon(
            Icons.menu,
          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.playlist_add_circle),
            tooltip: "GameCenter",
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => Gamecenter()));
            },
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => timer()));
        },
        child: Text("count"),
      ),
    );
  }
}
