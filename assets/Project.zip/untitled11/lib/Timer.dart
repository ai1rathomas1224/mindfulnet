import 'dart:async';

import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';

class timer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: TimerPage(),
      theme: ThemeData(scaffoldBackgroundColor: Colors.pink),
    );
  }
}

class TimerPage extends StatefulWidget {
  @override
  _TimerPageState createState() => _TimerPageState();
}

class _TimerPageState extends State<TimerPage> {
  int workTime = 25 * 60;
  int breakTime = 5 * 60;
  bool timeStart = false;
  bool timeReset = false;
  var period = const Duration(seconds: 1);
  double percent = 0;

  void timeResetCount() {
    if (timeReset) {
      timeStart = false;
      workTime = 25 * 60;
    } else {
      timeReset = true;
      timeStart = false;
      workTime = 5 * 60;
    }
  }

  void timeStartCount() {
    if (timeStart) {
      timeStart = false;
    } else {
      timeStart = true;
    }

    Timer.periodic(period, (timer) {
      if (workTime < 1 || timeStart == false) {
        timer.cancel();
        workTime = 25 * 60;
        if (workTime < 0) {}
      } else {
        workTime--;
        percent = 1 - (workTime / (25 * 60));
      }
      setState(() {});
    });
  }

  String formatTime(int timeInSeconds) {
    String minutes = (timeInSeconds ~/ 60).toString().padLeft(2, '0');
    String seconds = (timeInSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              height: 10.0,
            ),
            Expanded(
              child: CircularPercentIndicator(
                  percent: percent,
                  animation: true,
                  animateFromLastPercent: true,
                  radius: 150.0,
                  lineWidth: 20.0,
                  progressColor: Colors.yellow,
                  center: Container(
                    width: 150,
                    height: 150,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: Colors.yellow,
                        borderRadius: BorderRadius.circular(15)),
                    child: Text(
                      '${formatTime(workTime)}',
                      style: const TextStyle(fontSize: 50),
                    ),
                  )),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              ElevatedButton(
                onPressed: () => timeStartCount(),
                child: Text(timeStart ? 'PAUSE' : 'START'),
              ),
              ElevatedButton(
                onPressed: () => timeResetCount(),
                child: const Text('Reset'),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
