import 'package:flutter/material.dart';
import 'package:untitled11/Game2.dart';
import 'package:untitled11/tictactoegpt.dart';

class Gamecenter extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.amber,
        body: Center(
          child: Row(
            children: [
              const SizedBox(),
              Expanded(
                  child: IconButton(
                icon: Image.asset("images/IMG_1011.jpeg"),
                iconSize: 150,
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => TicTacToe()));
                },
              )),
              Expanded(
                  child: IconButton(
                icon: Image.asset("images/RPS.png"),
                iconSize: 150,
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Game2()));
                },
              )),
            ],
          ),
        ));
  }
}
