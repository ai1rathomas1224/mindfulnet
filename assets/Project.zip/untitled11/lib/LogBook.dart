import 'package:flutter/material.dart';

class Logbook extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue,
        appBar: AppBar(
          title: const Text('LogBook'),
          centerTitle: true,
          backgroundColor: Colors.white,
        ));
  }
}
